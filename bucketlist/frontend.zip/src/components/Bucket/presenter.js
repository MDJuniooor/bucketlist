import React from 'react';
import LinesEllipsis from 'react-lines-ellipsis';
import './style.scss';

const Bucket = props => {
    {console.log(props)}
    return (
        <div className="Bucket">
            <div className="Bucket__Column1">
                <div className="centered">
                <img src={props.file} alt={props.file}/>
                </div>
            </div>
            <div className="Bucket__Column2">
                <h1>{props.location}</h1>
                <div className="Bucket__Genres">
                    <h1>{props.like_count} supporters</h1>
                </div>
                <div className="Bucket__Synopsis">
                    <LinesEllipsis
                        text={props.caption}
                        maxLine='2'
                        ellipsis='...'
                        trimRight
                        basedOn='letters'
                    />
                </div>
            </div>
        </div>
    )
}
export default Bucket