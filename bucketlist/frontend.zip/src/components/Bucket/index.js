import { connect } from "react-redux";
import Container from "./container";

export default connect()(Container);