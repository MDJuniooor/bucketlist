import { connect } from "react-redux";
import Container from "./container";

// Add all the actions for:
// Log in
// Sign up
// Recover Password
// Check username
// Check password

export default connect()(Container);
