import React from "react";
import PropTypes from "prop-types";
import styles from "./styles.scss";
import LoginForm from "../LoginForm";

const Auth = porps => <LoginForm/>

export default Auth;