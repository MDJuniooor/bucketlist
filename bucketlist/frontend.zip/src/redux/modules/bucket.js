// imports

import { actionCreators as userActions } from "./user";

// actions

const SET_BUCKET = "SET_BUCKET";
const LIKE_BUCKET = "LIKE_BUCKET";
const UNLIKE_BUCKET = "UNLIKE_BUCKET";

// action creators

function setBucket(bucket) {
    return{
        type: SET_BUCKET,
        bucket
    };
}

function doLikeBucket(bucketId){
    return{
        type: LIKE_BUCKET,
        bucketId
    }
}

function doUnLikeBucket(bucketId) {
    return{
        type: UNLIKE_BUCKET,
        bucketId
    }
}
// API actions

function getBucket(){
    return(dispatch, getState) => {
        fetch("/buckets/")
    .then(response => {
        return response.json();
    })
    .then(json => {
        dispatch(setBucket(json));
    });
    }
}

function likeBucket(bucketId) {
    return(dispatch, getState) => {
        dispatch(doLikeBucket(bucketId));
        const {user:{token}}= getState();
        fetch(`/buckets/${bucketId}/likes`,{
            method: "POST",
            headers: {
                Authorization: `JWT ${token}`
            }
        })
        .then(response => {
            if(response.status === 401){
                dispatch(userActions.logout());
            } else if(!response.ok){
                dispatch(doUnlikeBucket(bucketId));
            }
        });
    }
}

function doUnlikeBucket(bucketId) {
    
}
// initial state

const initialState = {};


// reducer

function reducer(state = initialState, action) {
    
    switch (action.type) {
        case SET_BUCKET:
            return applySetBucket(state, action);
        case LIKE_BUCKET:
            return applyLikeBucket(state, action);
        case UNLIKE_BUCKET:
            return applyUnLikeBucket(state, action);
        default:
            return state;
    }
}

// reducer functions

    function applySetBucket(state, action) {
        const { bucket } = action;
        return {
            ...state,
            bucket
        };
    }

    function applyLikeBucket(state, action) {
        
    }
    function applyUnLikeBucket(state, action) {

    }
// exports

const actionCreators = {
    getBucket,
};

export { actionCreators};
// export reducer by default

export default reducer;